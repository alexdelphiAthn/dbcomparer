# Suite de Herramientas de Base de Datos para MySQL

Conjunto completo de utilidades de línea de comandos para gestión de bases de datos MySQL/MariaDB desarrolladas en Delphi con UniDAC.

## 📦 Herramientas Incluidas

### 1. **DBComparer** - Comparador de Bases de Datos
Compara dos bases de datos y genera un script SQL con las diferencias.

**Casos de uso:**
- Sincronizar base de datos de desarrollo con producción
- Generar scripts de migración
- Detectar diferencias entre versiones
- Actualizar estructuras y datos

[📖 Ver documentación completa de DBComparer](README_DBComparer.md)

### 2. **DBBackup** - Generador de Backups
Crea copias de seguridad completas de bases de datos MySQL.

**Casos de uso:**
- Backups diarios automatizados
- Exportar estructura y datos
- Copias antes de migraciones
- Archivos para restauración

[📖 Ver documentación completa de DBBackup](README_DBBackup.md)

### 3. **DBRestore** - Ejecutor de Scripts SQL
Ejecuta scripts SQL con control avanzado de errores y logging.

**Casos de uso:**
- Restaurar backups
- Aplicar migraciones
- Ejecutar scripts masivos
- Importar datos con validación

[📖 Ver documentación completa de DBRestore](README_DBRestore.md)

## 🚀 Inicio Rápido

### Instalación

1. Compila los tres proyectos en Delphi:
   ```
   dcc32 DBComparer.dpr
   dcc32 DBBackup.dpr
   dcc32 DBRestore.dpr
   ```

2. Copia los ejecutables a una carpeta en tu PATH:
   ```
   copy *.exe C:\Herramientas\
   ```

### Ejemplos de Uso Común

#### Backup y Restauración

```bash
# 1. Crear backup
DBBackup -d produccion -o backup.sql

# 2. Restaurar en otra base de datos
DBRestore -d desarrollo -i backup.sql
```

#### Sincronización entre Bases de Datos

```bash
# 1. Comparar origen y destino
DBComparer --source-db produccion --target-db desarrollo -o sync.sql

# 2. Aplicar cambios
DBRestore -d desarrollo -i sync.sql
```

#### Migración de Datos

```bash
# 1. Exportar solo datos de tablas específicas
DBBackup -d origen --include clientes --include pedidos -o datos.sql

# 2. Importar con manejo de errores
DBRestore -d destino -i datos.sql --continue-on-error
```

## 📋 Workflows Típicos

### Workflow 1: Backup Diario Automatizado

```batch
REM backup_diario.bat
DBBackup -d produccion -o backups\prod_%DATE%.sql
```

Programa en el Programador de Tareas de Windows para ejecución nocturna.

### Workflow 2: Copiar Producción a Desarrollo

```batch
REM Ver script completo: copiar_bd.bat

REM 1. Backup de producción
DBBackup -h servidor-prod -d produccion -o temp.sql

REM 2. Restaurar en desarrollo
DBRestore -h localhost -d desarrollo -i temp.sql --continue-on-error
```

### Workflow 3: Aplicar Migración

```batch
REM 1. Comparar versión actual vs nueva
DBComparer --source-db modelo_v2 --target-db produccion -o migracion.sql

REM 2. Revisar script generado
notepad migracion.sql

REM 3. Aplicar migración
DBRestore -d produccion -i migracion.sql -l migracion.log
```

### Workflow 4: Sincronización Bidireccional

```batch
REM 1. Ver diferencias
DBComparer --source-db servidor1:bd --target-db servidor2:bd -o diff.sql

REM 2. Aplicar selectivamente
REM Edita diff.sql para eliminar cambios no deseados

REM 3. Ejecutar
DBRestore -d servidor2:bd -i diff.sql
```

## 🔧 Arquitectura del Proyecto

```
Suite de DB Tools
├── Core (Compartido)
│   ├── Core.Interfaces.pas      - Interfaces comunes
│   ├── Core.Types.pas            - Tipos compartidos
│   ├── Core.Helpers.pas          - Helpers base
│   ├── Core.Resources.pas        - Recursos y mensajes
│   └── Core.Engine.pas           - Motor del comparador
│
├── Providers (Base de datos)
│   ├── Providers.MySQL.pas       - Provider MySQL/MariaDB
│   └── Providers.MySQL.Helpers   - Helpers específicos MySQL
│
├── Herramientas
│   ├── DBComparer
│   │   ├── DBComparer.dpr
│   │   └── (usa Core + Providers)
│   │
│   ├── DBBackup
│   │   ├── DBBackup.dpr
│   │   ├── Backup.Engine.pas
│   │   └── Backup.Types.pas
│   │
│   └── DBRestore
│       ├── DBRestore.dpr
│       ├── Restore.Engine.pas
│       └── Restore.Types.pas
│
└── Scripts
    ├── backup_auto.bat           - Backup automático Windows
    ├── backup_auto.sh            - Backup automático Linux
    └── copiar_bd.bat             - Copiar BD completa
```

## 📊 Comparación de Herramientas

| Característica | DBComparer | DBBackup | DBRestore |
|----------------|------------|----------|-----------|
| **Propósito** | Comparar 2 BDs | Exportar BD | Importar SQL |
| **Conexiones** | 2 (origen + destino) | 1 (origen) | 1 (destino) |
| **Salida** | Script SQL (ALTER/UPDATE) | Script SQL (CREATE/INSERT) | - |
| **Entrada** | 2 BDs | 1 BD | Archivo SQL |
| **Datos** | Opcional (diff) | Opcional (completo) | Ejecuta todo |
| **Transacciones** | No aplica | No aplica | Sí |
| **Logging** | Básico | Básico | Avanzado |
| **Errores** | - | - | Control completo |

## 🎯 Casos de Uso por Herramienta

### DBComparer
- ✅ Sincronizar desarrollo ↔ producción
- ✅ Detectar cambios no documentados
- ✅ Generar scripts de migración
- ✅ Auditar diferencias de esquema
- ❌ Backups completos (usa DBBackup)

### DBBackup
- ✅ Backups nocturnos programados
- ✅ Exportar antes de cambios importantes
- ✅ Crear copias de seguridad
- ✅ Archivar versiones de datos
- ❌ Comparar BDs (usa DBComparer)

### DBRestore
- ✅ Restaurar backups
- ✅ Aplicar scripts de migración
- ✅ Importar datos masivos
- ✅ Ejecutar procedures/functions
- ❌ Generar scripts (usa DBBackup)

## ⚙️ Requisitos del Sistema

### Desarrollo
- Delphi 10.3 Rio o superior
- UniDAC (Universal Data Access Components)
- Componentes MySQL de DevArt

### Ejecución
- Windows 7/10/11 o Windows Server 2012+
- MySQL 5.7+ o MariaDB 10.3+
- Permisos de lectura/escritura en la BD

## 🔐 Seguridad

### Buenas Prácticas

1. **No almacenar contraseñas en scripts**
   ```batch
   REM Malo
   DBBackup -p MiPassword123 -d produccion
   
   REM Mejor - pedir contraseña
   SET /P PASS=Ingrese contraseña: 
   DBBackup -p %PASS% -d produccion
   ```

2. **Usar usuarios con permisos limitados**
   ```sql
   -- Usuario solo para backup
   CREATE USER 'backup_user'@'%' IDENTIFIED BY 'password';
   GRANT SELECT, SHOW VIEW ON produccion.* TO 'backup_user'@'%';
   
   -- Usuario solo para restore
   CREATE USER 'restore_user'@'localhost' IDENTIFIED BY 'password';
   GRANT ALL PRIVILEGES ON desarrollo.* TO 'restore_user'@'localhost';
   ```

3. **Proteger archivos de backup**
   - Usar permisos restrictivos en carpetas de backup
   - Cifrar backups sensibles
   - Rotar y eliminar backups antiguos

## 📝 Tips y Trucos

### 1. Backup Incremental Simulado

```batch
REM Backup completo semanal
IF %DATE:~0,2%==01 (
    DBBackup -d mydb -o backup_completo.sql
) ELSE (
    REM Solo estructura + tablas modificadas
    DBBackup -d mydb --include logs --include auditoria -o backup_incremental.sql
)
```

### 2. Validar Script Antes de Ejecutar

```batch
REM Ejecutar en BD de prueba primero
DBRestore -d test_db -i script.sql --continue-on-error

REM Si ok, aplicar en producción
DBRestore -d produccion -i script.sql
```

### 3. Backup Selectivo por Tamaño

```batch
REM Tablas pequeñas: completo
DBBackup -d mydb --exclude logs -o backup_small.sql

REM Tablas grandes: solo estructura
DBBackup -d mydb --include logs --structure-only -o backup_large_struct.sql
```

### 4. Logging Centralizado

```batch
SET LOG_DIR=C:\Logs\Database

DBBackup -d mydb -o backup.sql > %LOG_DIR%\backup_%DATE%.log 2>&1
DBRestore -d mydb -i backup.sql -l %LOG_DIR%\restore_%DATE%.log
```

## 🐛 Solución de Problemas Comunes

### "Access denied for user"
→ Verificar permisos del usuario MySQL

### "Table doesn't exist"
→ Verificar que la BD de destino existe y está vacía (para restore)

### "Duplicate entry"
→ Usar `--continue-on-error` en DBRestore

### "Out of memory"
→ Dividir el script en partes más pequeñas

### "Lost connection to MySQL server"
→ Aumentar `wait_timeout` y `max_allowed_packet` en MySQL

## 📈 Optimización de Rendimiento

### Para Backups Grandes

```batch
REM 1. Solo estructura
DBBackup -d huge_db --structure-only -o structure.sql

REM 2. Datos por tabla (en paralelo si es posible)
DBBackup -d huge_db --include tabla1 -o data_tabla1.sql
DBBackup -d huge_db --include tabla2 -o data_tabla2.sql
```

### Para Restores Lentos

```batch
REM Desactivar transacciones
DBRestore -d mydb -i backup.sql --no-transactions

REM O dividir el script
split -l 10000 backup.sql chunk_
DBRestore -d mydb -i chunk_aa --no-transactions
DBRestore -d mydb -i chunk_ab --no-transactions
```

## 🔄 Actualizaciones y Mantenimiento

### Versión Actual
- DBComparer: 1.0
- DBBackup: 1.0
- DBRestore: 1.0

### Mejoras Futuras Planeadas
- [ ] Soporte para PostgreSQL
- [ ] Soporte para SQL Server
- [ ] Compresión de backups (gzip)
- [ ] Backups incrementales reales
- [ ] Interfaz gráfica opcional
- [ ] Cifrado de backups

## 📞 Soporte

Para reportar bugs o solicitar características:
- Email: alejandro.laorden@proton.me
- GitHub: (tu repositorio)

## 📄 Licencia

Uso libre para proyectos personales y comerciales.

## 👏 Créditos

Desarrollado por **Alejandro La Orden**  
2025

Construido con:
- Embarcadero Delphi
- DevArt UniDAC
- MySQL/MariaDB

---

**¡Disfruta de tus herramientas de base de datos!** 🎉
