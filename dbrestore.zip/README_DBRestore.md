# DBRestore - Ejecutor de Scripts SQL para MySQL

## Descripción

DBRestore es una herramienta de línea de comandos para ejecutar scripts SQL en MySQL con control avanzado de errores, logging detallado y opciones de continuación. Es el complemento perfecto para **DBBackup**.

## Características

- ✅ Ejecución de scripts SQL de cualquier tamaño
- ✅ Soporte completo para DELIMITER (procedures, functions, triggers)
- ✅ Manejo inteligente de comentarios (-- y /* */)
- ✅ Control de errores configurable
- ✅ Logging detallado con timestamps
- ✅ Barra de progreso en tiempo real
- ✅ Soporte de transacciones (COMMIT/ROLLBACK)
- ✅ Modo verbose y modo silencioso
- ✅ Continuar ante errores o detenerse
- ✅ Estadísticas de ejecución

## Compilación

```
dcc32 DBRestore.dpr
```

O compila desde el IDE de Delphi.

## Requisitos

- Delphi 10.3 o superior
- UniDAC (Universal Data Access Components)
- Conexión a servidor MySQL/MariaDB

## Uso Básico

### Ejecutar un backup

```bash
DBRestore -d nombre_bd -i backup.sql
```

### Con autenticación

```bash
DBRestore -h 192.168.1.100 -u admin -p secreto -d nombre_bd -i backup.sql
```

### Continuar aunque haya errores

```bash
DBRestore -d nombre_bd -i script.sql --continue-on-error
```

### Ignorar todos los errores

```bash
DBRestore -d nombre_bd -i script.sql --ignore-errors
```

### Con archivo de log personalizado

```bash
DBRestore -d nombre_bd -i script.sql -l mi_restauracion.log
```

## Opciones de Conexión

| Opción | Descripción | Default |
|--------|-------------|---------|
| `-h, --host` | Host del servidor MySQL | localhost |
| `-P, --port` | Puerto del servidor | 3306 |
| `-u, --user` | Usuario de MySQL | root |
| `-p, --password` | Contraseña | (vacío) |
| `-d, --database` | Nombre de la BD | **REQUERIDO** |

## Opciones de Archivo

| Opción | Descripción | Default |
|--------|-------------|---------|
| `-i, --input` | Archivo SQL a ejecutar | **REQUERIDO** |
| `-l, --log` | Archivo de log | `restore_YYYYMMDD_HHMMSS.log` |

## Opciones de Ejecución

| Opción | Descripción | Default |
|--------|-------------|---------|
| `--continue-on-error` | Continuar aunque haya errores | false |
| `--ignore-errors` | Ignorar TODOS los errores | false |
| `--stop-on-error` | Parar al primer error | false |
| `--no-transactions` | No usar transacciones | false |
| `--quiet` | Modo silencioso (solo errores) | false |
| `--no-progress` | No mostrar barra de progreso | false |

## Modos de Manejo de Errores

### 1. Modo Normal (default)
```bash
DBRestore -d mydb -i script.sql
```
- Se detiene al primer error
- Usa transacciones
- Hace ROLLBACK si hay error
- **Recomendado para**: Scripts críticos

### 2. Continuar con errores
```bash
DBRestore -d mydb -i script.sql --continue-on-error
```
- Continúa ejecutando aunque haya errores
- Registra los errores en el log
- Hace COMMIT al final (parcial)
- **Recomendado para**: Migr aciones con conflictos conocidos

### 3. Ignorar errores
```bash
DBRestore -d mydb -i script.sql --ignore-errors
```
- Ignora TODOS los errores completamente
- Continúa sin registrar fallos
- **Recomendado para**: Scripts con sentencias opcionales

### 4. Detenerse inmediatamente
```bash
DBRestore -d mydb -i script.sql --stop-on-error
```
- Para al primer error sin intentar más comandos
- **Recomendado para**: Validación de scripts

## Ejemplos de Uso

### 1. Restaurar backup completo

```bash
DBRestore -d produccion -i produccion_backup_20250214.sql
```

### 2. Restaurar con logging detallado

```bash
DBRestore -d desarrollo -i backup.sql -l restore_dev.log
```

### 3. Migración con errores esperados

```bash
# Por ejemplo, si el script intenta crear tablas que ya existen
DBRestore -d migracion -i estructura_nueva.sql --continue-on-error
```

### 4. Ejecutar script de procedures

```bash
# Los DELIMITER se procesan automáticamente
DBRestore -d mydb -i stored_procedures.sql
```

### 5. Modo silencioso para scripts automatizados

```bash
DBRestore -d mydb -i script.sql --quiet --ignore-errors
```

### 6. Sin transacciones (autocommit)

```bash
# Útil para scripts muy grandes o que usan DDL incompatible con transacciones
DBRestore -d mydb -i script.sql --no-transactions
```

## Formato del Archivo de Log

El archivo de log incluye:

```
[2025-02-14 15:30:45] ==============================================
[2025-02-14 15:30:45] Iniciando ejecución de script SQL
[2025-02-14 15:30:45] Archivo: backup.sql
[2025-02-14 15:30:45] ==============================================
[2025-02-14 15:30:45] Tamaño del script: 1524389 bytes
[2025-02-14 15:30:45] Líneas del script: 12456
[2025-02-14 15:30:45] Analizando script y extrayendo comandos...
[2025-02-14 15:30:46] Comandos encontrados: 3421
[2025-02-14 15:30:46] Iniciando transacción...
[2025-02-14 15:30:47] [1/3421] Ejecutando: CREATE TABLE clientes...
[2025-02-14 15:30:47]   ✓ Éxito - Filas afectadas: 0
[2025-02-14 15:30:48] ERROR: Comando #245 falló: Table 'productos' already exists
[2025-02-14 15:30:48] ERROR: Comando: CREATE TABLE productos (id INT...)
[2025-02-14 15:35:12] Confirmando transacción...
[2025-02-14 15:35:13] ==============================================
[2025-02-14 15:35:13] Ejecución completada
[2025-02-14 15:35:13] ==============================================
[2025-02-14 15:35:13] Tiempo transcurrido: 00:04:26
[2025-02-14 15:35:13] Comandos totales: 3421
[2025-02-14 15:35:13] Comandos ejecutados: 3421
[2025-02-14 15:35:13] Éxitos: 3418
[2025-02-14 15:35:13] Errores: 3
[2025-02-14 15:35:13] Advertencias: 0
[2025-02-14 15:35:13] ==============================================
```

## Características Avanzadas

### Procesamiento de DELIMITER

DBRestore maneja automáticamente los comandos `DELIMITER`:

```sql
DELIMITER $$

CREATE PROCEDURE mi_proc()
BEGIN
  SELECT * FROM tabla;
END$$

DELIMITER ;
```

Se ejecuta correctamente sin intervención manual.

### Manejo de Comentarios

Elimina automáticamente:
- Comentarios de línea: `-- Esto es un comentario`
- Comentarios multi-línea: `/* Comentario */`

### Detección Inteligente de Comandos

Detecta automáticamente:
- SELECT, SHOW, DESCRIBE → Usa `Open`
- INSERT, UPDATE, DELETE, CREATE, ALTER, DROP → Usa `ExecSQL`

### Transacciones

- **Con transacciones (default)**: Todo se hace en una transacción, ROLLBACK si falla
- **Sin transacciones**: Cada comando se ejecuta independientemente (autocommit)

## Salida en Consola

### Modo Normal

```
==============================================
DBRestore - Ejecutando script SQL en MySQL
==============================================
Host: localhost:3306
Base de datos: midb
Usuario: root
Archivo de entrada: backup.sql
Archivo de log: restore_20250214_153045.log
Continuar con errores: False
Ignorar errores: False
Usar transacciones: True
==============================================

Conectando a la base de datos...
Conexión establecida.

Ejecutando script SQL...

Progreso: 3421/3421 (100%) - Éxitos: 3418 - Errores: 3

==============================================
Resumen de ejecución
==============================================
Comandos ejecutados: 3421
Comandos exitosos: 3418
Errores encontrados: 3
Advertencias: 0
==============================================

ATENCIÓN: Se encontraron 3 errores durante la ejecución.
Consulte el archivo de log para más detalles: restore_20250214_153045.log
```

### Modo Verbose (sin --quiet)

```
[1/3421] Ejecutando: CREATE TABLE clientes (id INT...)
  ✓ Éxito - Filas afectadas: 0
[2/3421] Ejecutando: INSERT INTO clientes VALUES (1, 'Juan')...
  ✓ Éxito - Filas afectadas: 1
```

## Códigos de Salida

| Código | Significado |
|--------|-------------|
| 0 | Ejecución exitosa sin errores |
| 1 | Hubo errores durante la ejecución |

## Casos de Uso Comunes

### Restaurar backup diario

```bash
DBRestore -d produccion -i backup_diario.sql
```

### Aplicar migraciones de desarrollo

```bash
# Continuar aunque algunas tablas ya existan
DBRestore -d desarrollo -i migracion_v2.sql --continue-on-error
```

### Importar datos masivos

```bash
# Sin transacciones para mejor rendimiento
DBRestore -d warehouse -i datos_masivos.sql --no-transactions --quiet
```

### Ejecutar procedures y functions

```bash
DBRestore -d mydb -i stored_routines.sql
```

### Validar script sin ejecutar

```bash
# Usa --stop-on-error para validar sintaxis
DBRestore -d test_db -i script.sql --stop-on-error
```

## Integración con DBBackup

DBRestore está diseñado para trabajar perfectamente con DBBackup:

```bash
# 1. Crear backup
DBBackup -d produccion -o backup.sql

# 2. Restaurar backup
DBRestore -d desarrollo -i backup.sql
```

## Solución de Problemas

### Error: "Cannot execute command in transaction"

Algunos comandos DDL no soportan transacciones. Usa `--no-transactions`:

```bash
DBRestore -d mydb -i script.sql --no-transactions
```

### Script muy grande se queda sin memoria

Divide el script en partes más pequeñas o aumenta la memoria de Delphi.

### Errores de "Table already exists"

Usa `--continue-on-error` o edita el script para agregar `IF NOT EXISTS`:

```bash
DBRestore -d mydb -i backup.sql --continue-on-error
```

### No se muestran mensajes de progreso

Verifica que no estés usando `--quiet` o `--no-progress`.

## Diferencias con mysql client

| Característica | DBRestore | mysql client |
|----------------|-----------|--------------|
| Manejo de errores | Configurable | Limitado |
| Logging | Detallado con timestamps | Básico |
| Progreso | Barra visual | No |
| DELIMITER | Automático | Manual |
| Estadísticas | Completas | Limitadas |
| Transacciones | Configurables | Manual |
| Windows | Nativo | Requiere instalación |

## Estructura del Proyecto

```
DBRestore.dpr                - Programa principal
Restore.Engine.pas           - Motor de ejecución
Restore.Types.pas            - Tipos y opciones
Core_Interfaces.pas          - Interfaces (compartidas con DBBackup)
Providers_MySQL.pas          - Provider MySQL
```

## Notas Importantes

- Los comandos se ejecutan secuencialmente (no en paralelo)
- El parser de comandos es robusto pero puede fallar con SQL muy complejo
- Los comentarios se eliminan antes de ejecutar
- Compatible con MySQL 5.7+ y MariaDB 10.3+
- El archivo de log se crea siempre, incluso sin errores

## Autor

Alejandro La Orden  
2025

## Licencia

Uso libre para proyectos personales y comerciales.
