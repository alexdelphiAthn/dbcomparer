unit Restore.Engine;

interface

uses
  Core.Interfaces, Restore.Types, System.Classes, System.SysUtils,
  Uni, Data.DB;

type
  TDBRestoreEngine = class
  private
    FProvider: IDBMetadataProvider;
    FInputFile: string;
    FLogFile: string;
    FOptions: TRestoreOptions;
    FLog: TStringList;
    FExecutedCount: Integer;
    FSuccessCount: Integer;
    FErrorCount: Integer;
    FWarningCount: Integer;
    FConn: TUniConnection;
    FCurrentDelimiter: string;
    
    procedure Log(const Message: string);
    procedure LogError(const Message: string);
    procedure LogWarning(const Message: string);
    function ExtractCommands(const SQLScript: string): TStringList;
    function ExecuteCommand(const Command: string): TCommandResult;
    procedure SaveLog;
    function RemoveComments(const SQL: string): string;
    function IsDelimiterCommand(const Command: string; out NewDelimiter: string): Boolean;
  public
    constructor Create(Provider: IDBMetadataProvider;
                       const InputFile, LogFile: string;
                       Options: TRestoreOptions);
    destructor Destroy; override;
    procedure ExecuteScript;
    function GetExecutedCount: Integer;
    function GetSuccessCount: Integer;
    function GetErrorCount: Integer;
    function GetWarningCount: Integer;
  end;

implementation

uses
  System.StrUtils;

constructor TDBRestoreEngine.Create(Provider: IDBMetadataProvider;
                                    const InputFile, LogFile: string;
                                    Options: TRestoreOptions);
begin
  FProvider := Provider;
  FInputFile := InputFile;
  FLogFile := LogFile;
  FOptions := Options;
  FLog := TStringList.Create;
  FExecutedCount := 0;
  FSuccessCount := 0;
  FErrorCount := 0;
  FWarningCount := 0;
  FCurrentDelimiter := ';';
  
  // Obtener la conexión real del provider
  // Esto asume que TMySQLMetadataProvider expone FConn o lo podemos obtener
  // Por ahora, crearemos una nueva conexión
  FConn := nil;
end;

destructor TDBRestoreEngine.Destroy;
begin
  SaveLog;
  FLog.Free;
  inherited;
end;

procedure TDBRestoreEngine.Log(const Message: string);
begin
  FLog.Add(Format('[%s] %s', [FormatDateTime('yyyy-mm-dd hh:nn:ss', Now), Message]));
  if FOptions.VerboseMode then
    WriteLn(Message);
end;

procedure TDBRestoreEngine.LogError(const Message: string);
begin
  FLog.Add(Format('[%s] ERROR: %s', [FormatDateTime('yyyy-mm-dd hh:nn:ss', Now), Message]));
  WriteLn('ERROR: ' + Message);
end;

procedure TDBRestoreEngine.LogWarning(const Message: string);
begin
  FLog.Add(Format('[%s] WARNING: %s', [FormatDateTime('yyyy-mm-dd hh:nn:ss', Now), Message]));
  if not FOptions.IgnoreWarnings then
    WriteLn('WARNING: ' + Message);
end;

procedure TDBRestoreEngine.SaveLog;
begin
  try
    FLog.SaveToFile(FLogFile);
  except
    on E: Exception do
      WriteLn('Error al guardar log: ' + E.Message);
  end;
end;

function TDBRestoreEngine.RemoveComments(const SQL: string): string;
var
  Lines: TStringList;
  i: Integer;
  Line, TrimmedLine: string;
  InMultiLineComment: Boolean;
  Pos1, Pos2: Integer;
begin
  Lines := TStringList.Create;
  try
    Lines.Text := SQL;
    InMultiLineComment := False;
    
    for i := Lines.Count - 1 downto 0 do
    begin
      Line := Lines[i];
      TrimmedLine := Trim(Line);
      
      // Verificar comentarios multi-línea
      if InMultiLineComment then
      begin
        Pos2 := Pos('*/', Line);
        if Pos2 > 0 then
        begin
          Line := Copy(Line, Pos2 + 2, Length(Line));
          InMultiLineComment := False;
        end
        else
        begin
          Lines.Delete(i);
          Continue;
        end;
      end;
      
      // Buscar inicio de comentario multi-línea
      Pos1 := Pos('/*', Line);
      if Pos1 > 0 then
      begin
        Pos2 := PosEx('*/', Line, Pos1);
        if Pos2 > 0 then
          Line := Copy(Line, 1, Pos1 - 1) + Copy(Line, Pos2 + 2, Length(Line))
        else
        begin
          Line := Copy(Line, 1, Pos1 - 1);
          InMultiLineComment := True;
        end;
      end;
      
      // Comentarios de línea simple (--)
      Pos1 := Pos('--', Line);
      if Pos1 > 0 then
        Line := Copy(Line, 1, Pos1 - 1);
      
      Lines[i] := Line;
      
      // Eliminar líneas vacías
      if Trim(Lines[i]) = '' then
        Lines.Delete(i);
    end;
    
    Result := Lines.Text;
  finally
    Lines.Free;
  end;
end;

function TDBRestoreEngine.IsDelimiterCommand(const Command: string; 
                                              out NewDelimiter: string): Boolean;
var
  UpperCmd: string;
  Pos: Integer;
begin
  Result := False;
  NewDelimiter := '';
  UpperCmd := UpperCase(Trim(Command));
  
  if StartsText('DELIMITER', UpperCmd) then
  begin
    Result := True;
    // Extraer el nuevo delimitador
    Pos := Length('DELIMITER') + 1;
    NewDelimiter := Trim(Copy(Command, Pos, Length(Command)));
    if NewDelimiter = '' then
      NewDelimiter := ';';
  end;
end;

function TDBRestoreEngine.ExtractCommands(const SQLScript: string): TStringList;
var
  CleanSQL: string;
  CurrentCommand: string;
  i: Integer;
  Ch: Char;
  InString: Boolean;
  StringChar: Char;
  NewDelimiter: string;
begin
  Result := TStringList.Create;
  
  // Remover comentarios
  CleanSQL := RemoveComments(SQLScript);
  
  CurrentCommand := '';
  InString := False;
  StringChar := #0;
  
  for i := 1 to Length(CleanSQL) do
  begin
    Ch := CleanSQL[i];
    
    // Manejar cadenas (entre comillas)
    if (Ch = '''') or (Ch = '"') or (Ch = '`') then
    begin
      if not InString then
      begin
        InString := True;
        StringChar := Ch;
      end
      else if Ch = StringChar then
      begin
        // Verificar si es escape (\' o '')
        if (i < Length(CleanSQL)) and (CleanSQL[i + 1] = StringChar) then
        begin
          CurrentCommand := CurrentCommand + Ch;
          Inc(i);
        end
        else
          InString := False;
      end;
    end;
    
    CurrentCommand := CurrentCommand + Ch;
    
    // Verificar delimitador solo si no estamos en cadena
    if not InString then
    begin
      if EndsText(FCurrentDelimiter, Trim(CurrentCommand)) then
      begin
        // Remover el delimitador del comando
        CurrentCommand := Trim(CurrentCommand);
        CurrentCommand := Copy(CurrentCommand, 1, 
                               Length(CurrentCommand) - Length(FCurrentDelimiter));
        CurrentCommand := Trim(CurrentCommand);
        
        if CurrentCommand <> '' then
        begin
          // Verificar si es comando DELIMITER
          if IsDelimiterCommand(CurrentCommand, NewDelimiter) then
          begin
            FCurrentDelimiter := NewDelimiter;
            Log(Format('Delimitador cambiado a: %s', [FCurrentDelimiter]));
          end
          else
            Result.Add(CurrentCommand);
        end;
        
        CurrentCommand := '';
      end;
    end;
  end;
  
  // Agregar comando final si existe
  CurrentCommand := Trim(CurrentCommand);
  if CurrentCommand <> '' then
    Result.Add(CurrentCommand);
end;

function TDBRestoreEngine.ExecuteCommand(const Command: string): TCommandResult;
var
  Query: TUniQuery;
begin
  Result.Success := False;
  Result.ErrorMessage := '';
  Result.WarningMessage := '';
  Result.AffectedRows := 0;
  Result.CommandText := Command;
  
  Query := TUniQuery.Create(nil);
  try
    Query.Connection := FConn;
    
    try
      Query.SQL.Text := Command;
      
      // Determinar si es SELECT o comando de modificación
      if StartsText('SELECT', Trim(UpperCase(Command))) or
         StartsText('SHOW', Trim(UpperCase(Command))) or
         StartsText('DESCRIBE', Trim(UpperCase(Command))) or
         StartsText('DESC', Trim(UpperCase(Command))) then
      begin
        Query.Open;
        Result.AffectedRows := Query.RecordCount;
        Query.Close;
      end
      else
      begin
        Query.ExecSQL;
        Result.AffectedRows := Query.RowsAffected;
      end;
      
      Result.Success := True;
      
    except
      on E: Exception do
      begin
        Result.Success := False;
        Result.ErrorMessage := E.Message;
      end;
    end;
    
  finally
    Query.Free;
  end;
end;

procedure TDBRestoreEngine.ExecuteScript;
var
  SQLScript: string;
  Commands: TStringList;
  i: Integer;
  CmdResult: TCommandResult;
  StartTime, EndTime: TDateTime;
  ProgressInterval: Integer;
  ScriptLines: TStringList;
begin
  Log('==============================================');
  Log('Iniciando ejecución de script SQL');
  Log(Format('Archivo: %s', [FInputFile]));
  Log('==============================================');
  
  // Obtener la conexión del provider
  FConn := FProvider.GetConnection as TUniConnection;
  
  if not Assigned(FConn) then
    raise Exception.Create('No se pudo obtener la conexión de base de datos');
  
  // Leer el archivo
  ScriptLines := TStringList.Create;
    try
      ScriptLines.LoadFromFile(FInputFile);
      SQLScript := ScriptLines.Text;
      
      Log(Format('Tamaño del script: %d bytes', [Length(SQLScript)]));
      Log(Format('Líneas del script: %d', [ScriptLines.Count]));
      Log('');
      
    finally
      ScriptLines.Free;
    end;
    
    // Extraer comandos
    Log('Analizando script y extrayendo comandos...');
    Commands := ExtractCommands(SQLScript);
    try
      Log(Format('Comandos encontrados: %d', [Commands.Count]));
      Log('');
      
      if FOptions.UseTransactions then
      begin
        Log('Iniciando transacción...');
        FConn.StartTransaction;
      end;
      
      StartTime := Now;
      ProgressInterval := Max(1, Commands.Count div 20); // Mostrar progreso cada 5%
      
      // Ejecutar comandos
      for i := 0 to Commands.Count - 1 do
      begin
        Inc(FExecutedCount);
        
        // Mostrar progreso
        if FOptions.ShowProgress and ((i mod ProgressInterval = 0) or (i = Commands.Count - 1)) then
        begin
          Write(Format(#13'Progreso: %d/%d (%d%%) - Éxitos: %d - Errores: %d',
                      [i + 1, Commands.Count, 
                       Round((i + 1) * 100 / Commands.Count),
                       FSuccessCount, FErrorCount]));
        end;
        
        // Log detallado del comando (solo en verbose)
        if FOptions.VerboseMode and not FOptions.ShowProgress then
        begin
          if Length(Commands[i]) > 100 then
            Log(Format('[%d/%d] Ejecutando: %s...', 
                      [i + 1, Commands.Count, Copy(Commands[i], 1, 100)]))
          else
            Log(Format('[%d/%d] Ejecutando: %s', 
                      [i + 1, Commands.Count, Commands[i]]));
        end;
        
        CmdResult := ExecuteCommand(Commands[i]);
        
        if CmdResult.Success then
        begin
          Inc(FSuccessCount);
          if FOptions.VerboseMode and not FOptions.ShowProgress then
            Log(Format('  ✓ Éxito - Filas afectadas: %d', [CmdResult.AffectedRows]));
        end
        else
        begin
          Inc(FErrorCount);
          LogError(Format('Comando #%d falló: %s', [i + 1, CmdResult.ErrorMessage]));
          LogError(Format('Comando: %s', [Commands[i]]));
          
          if FOptions.StopOnFirstError then
          begin
            Log('Deteniendo ejecución por error (--stop-on-error)');
            if FOptions.UseTransactions then
            begin
              Log('Revirtiendo transacción...');
              FConn.Rollback;
            end;
            Break;
          end;
          
          if not FOptions.ContinueOnError and not FOptions.IgnoreErrors then
          begin
            Log('Deteniendo ejecución por error');
            if FOptions.UseTransactions then
            begin
              Log('Revirtiendo transacción...');
              FConn.Rollback;
            end;
            Break;
          end;
        end;
        
        if CmdResult.WarningMessage <> '' then
        begin
          Inc(FWarningCount);
          LogWarning(CmdResult.WarningMessage);
        end;
      end;
      
      if FOptions.ShowProgress then
        WriteLn(''); // Nueva línea después de la barra de progreso
      
      EndTime := Now;
      
      // Commit si todo salió bien
      if FOptions.UseTransactions then
      begin
        if (FErrorCount = 0) or FOptions.IgnoreErrors then
        begin
          Log('Confirmando transacción...');
          FConn.Commit;
        end
        else
        begin
          Log('Revirtiendo transacción por errores...');
          FConn.Rollback;
        end;
      end;
      
      Log('');
      Log('==============================================');
      Log('Ejecución completada');
      Log('==============================================');
      Log(Format('Tiempo transcurrido: %s', 
                [FormatDateTime('hh:nn:ss', EndTime - StartTime)]));
      Log(Format('Comandos totales: %d', [Commands.Count]));
      Log(Format('Comandos ejecutados: %d', [FExecutedCount]));
      Log(Format('Éxitos: %d', [FSuccessCount]));
      Log(Format('Errores: %d', [FErrorCount]));
      Log(Format('Advertencias: %d', [FWarningCount]));
      Log('==============================================');
      
    finally
      Commands.Free;
    end;
end;

function TDBRestoreEngine.GetExecutedCount: Integer;
begin
  Result := FExecutedCount;
end;

function TDBRestoreEngine.GetSuccessCount: Integer;
begin
  Result := FSuccessCount;
end;

function TDBRestoreEngine.GetErrorCount: Integer;
begin
  Result := FErrorCount;
end;

function TDBRestoreEngine.GetWarningCount: Integer;
begin
  Result := FWarningCount;
end;

end.
