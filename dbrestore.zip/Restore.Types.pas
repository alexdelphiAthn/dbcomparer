unit Restore.Types;

interface

type
  TRestoreOptions = record
    ContinueOnError: Boolean;    // Continuar aunque haya errores
    IgnoreErrors: Boolean;       // Ignorar completamente los errores (no fallar)
    VerboseMode: Boolean;        // Mostrar información detallada
    UseTransactions: Boolean;    // Usar transacciones (ROLLBACK si falla)
    ShowProgress: Boolean;       // Mostrar progreso de ejecución
    StopOnFirstError: Boolean;   // Parar al primer error
    IgnoreWarnings: Boolean;     // No mostrar advertencias
  end;

  TCommandResult = record
    Success: Boolean;
    ErrorMessage: string;
    WarningMessage: string;
    AffectedRows: Integer;
    CommandText: string;
  end;

implementation

end.
