program DBRestore;

{$APPTYPE CONSOLE}

{$R *.res}

uses
  System.SysUtils,
  System.Classes,
  Restore.Engine in 'Restore.Engine.pas',
  Restore.Types in 'Restore.Types.pas',
  Providers.MySQL in 'Providers_MySQL.pas',
  Providers.MySQL.Helpers in 'Providers_MySQL_Helpers.pas',
  Core.Interfaces in 'Core_Interfaces.pas',
  Core.Types in 'Core_Types.pas',
  Core.Helpers in 'Core_Helpers.pas';

var
  Host, Database, User, Password, InputFile, LogFile: string;
  Port: Integer;
  Provider: IDBMetadataProvider;
  Engine: TDBRestoreEngine;
  Options: TRestoreOptions;
  i: Integer;
  Param: string;

begin
  try
    // Valores por defecto
    Host := 'localhost';
    Port := 3306;
    Database := '';
    User := 'root';
    Password := '';
    InputFile := '';
    LogFile := '';
    
    // Opciones por defecto
    Options.ContinueOnError := False;
    Options.IgnoreErrors := False;
    Options.VerboseMode := True;
    Options.UseTransactions := True;
    Options.ShowProgress := True;
    Options.StopOnFirstError := False;
    Options.IgnoreWarnings := True;
    
    // Parsear parámetros
    i := 1;
    while i <= ParamCount do
    begin
      Param := ParamStr(i);
      
      if (Param = '-h') or (Param = '--host') then
      begin
        Inc(i);
        if i <= ParamCount then Host := ParamStr(i);
      end
      else if (Param = '-P') or (Param = '--port') then
      begin
        Inc(i);
        if i <= ParamCount then Port := StrToIntDef(ParamStr(i), 3306);
      end
      else if (Param = '-u') or (Param = '--user') then
      begin
        Inc(i);
        if i <= ParamCount then User := ParamStr(i);
      end
      else if (Param = '-p') or (Param = '--password') then
      begin
        Inc(i);
        if i <= ParamCount then Password := ParamStr(i);
      end
      else if (Param = '-d') or (Param = '--database') then
      begin
        Inc(i);
        if i <= ParamCount then Database := ParamStr(i);
      end
      else if (Param = '-i') or (Param = '--input') then
      begin
        Inc(i);
        if i <= ParamCount then InputFile := ParamStr(i);
      end
      else if (Param = '-l') or (Param = '--log') then
      begin
        Inc(i);
        if i <= ParamCount then LogFile := ParamStr(i);
      end
      else if (Param = '--continue-on-error') then
        Options.ContinueOnError := True
      else if (Param = '--ignore-errors') then
      begin
        Options.IgnoreErrors := True;
        Options.ContinueOnError := True;
      end
      else if (Param = '--stop-on-error') then
        Options.StopOnFirstError := True
      else if (Param = '--no-transactions') then
        Options.UseTransactions := False
      else if (Param = '--quiet') then
        Options.VerboseMode := False
      else if (Param = '--no-progress') then
        Options.ShowProgress := False
      else if (Param = '--help') then
      begin
        WriteLn('DBRestore - Utilidad de restauración de scripts SQL para MySQL');
        WriteLn('');
        WriteLn('Uso: DBRestore [opciones]');
        WriteLn('');
        WriteLn('Opciones de conexión:');
        WriteLn('  -h, --host <host>         Host del servidor MySQL (default: localhost)');
        WriteLn('  -P, --port <port>         Puerto del servidor MySQL (default: 3306)');
        WriteLn('  -u, --user <user>         Usuario de MySQL (default: root)');
        WriteLn('  -p, --password <pass>     Contraseña de MySQL');
        WriteLn('  -d, --database <db>       Nombre de la base de datos (REQUERIDO)');
        WriteLn('');
        WriteLn('Opciones de archivo:');
        WriteLn('  -i, --input <file>        Archivo SQL a ejecutar (REQUERIDO)');
        WriteLn('  -l, --log <file>          Archivo de log (default: restore_YYYYMMDD_HHMMSS.log)');
        WriteLn('');
        WriteLn('Opciones de ejecución:');
        WriteLn('  --continue-on-error       Continuar ejecutando aunque haya errores');
        WriteLn('  --ignore-errors           Ignorar todos los errores (implica --continue-on-error)');
        WriteLn('  --stop-on-error           Detener al primer error (comportamiento por defecto)');
        WriteLn('  --no-transactions         No usar transacciones (ejecutar cada comando directamente)');
        WriteLn('  --quiet                   Modo silencioso (solo errores)');
        WriteLn('  --no-progress             No mostrar barra de progreso');
        WriteLn('');
        WriteLn('Ejemplos:');
        WriteLn('  DBRestore -d mydb -i backup.sql');
        WriteLn('  DBRestore -h 192.168.1.100 -u admin -p secret -d mydb -i backup.sql');
        WriteLn('  DBRestore -d mydb -i backup.sql --continue-on-error -l restore.log');
        WriteLn('  DBRestore -d mydb -i script.sql --ignore-errors');
        WriteLn('');
        WriteLn('Notas:');
        WriteLn('  - El script puede contener comandos DELIMITER (se procesan correctamente)');
        WriteLn('  - Los comentarios (-- y /* */) se ignoran automáticamente');
        WriteLn('  - Si hay errores, se registran en el log con detalles');
        Exit;
      end;
      Inc(i);
    end;
    
    // Validar parámetros requeridos
    if Database = '' then
    begin
      WriteLn('Error: Debe especificar una base de datos con -d o --database');
      WriteLn('Use --help para ver las opciones disponibles');
      Exit;
    end;
    
    if InputFile = '' then
    begin
      WriteLn('Error: Debe especificar un archivo SQL con -i o --input');
      WriteLn('Use --help para ver las opciones disponibles');
      Exit;
    end;
    
    if not FileExists(InputFile) then
    begin
      WriteLn(Format('Error: El archivo "%s" no existe', [InputFile]));
      Exit;
    end;
    
    // Generar nombre de log si no se especificó
    if LogFile = '' then
      LogFile := Format('restore_%s.log', [FormatDateTime('yyyymmdd_hhnnss', Now)]);
    
    WriteLn('==============================================');
    WriteLn('DBRestore - Ejecutando script SQL en MySQL');
    WriteLn('==============================================');
    WriteLn(Format('Host: %s:%d', [Host, Port]));
    WriteLn(Format('Base de datos: %s', [Database]));
    WriteLn(Format('Usuario: %s', [User]));
    WriteLn(Format('Archivo de entrada: %s', [InputFile]));
    WriteLn(Format('Archivo de log: %s', [LogFile]));
    WriteLn(Format('Continuar con errores: %s', [BoolToStr(Options.ContinueOnError, True)]));
    WriteLn(Format('Ignorar errores: %s', [BoolToStr(Options.IgnoreErrors, True)]));
    WriteLn(Format('Usar transacciones: %s', [BoolToStr(Options.UseTransactions, True)]));
    WriteLn('==============================================');
    WriteLn('');
    
    // Crear instancias
    Provider := TMySQLMetadataProvider.Create(Host, Port, Database, User, Password);
    
    try
      Engine := TDBRestoreEngine.Create(Provider, InputFile, LogFile, Options);
      try
        WriteLn('Conectando a la base de datos...');
        Provider.Connect;
        WriteLn('Conexión establecida.');
        WriteLn('');
        
        WriteLn('Ejecutando script SQL...');
        WriteLn('');
        Engine.ExecuteScript;
        WriteLn('');
        
        WriteLn('==============================================');
        WriteLn('Resumen de ejecución');
        WriteLn('==============================================');
        WriteLn(Format('Comandos ejecutados: %d', [Engine.GetExecutedCount]));
        WriteLn(Format('Comandos exitosos: %d', [Engine.GetSuccessCount]));
        WriteLn(Format('Errores encontrados: %d', [Engine.GetErrorCount]));
        WriteLn(Format('Advertencias: %d', [Engine.GetWarningCount]));
        WriteLn('==============================================');
        
        if Engine.GetErrorCount > 0 then
        begin
          WriteLn('');
          WriteLn(Format('ATENCIÓN: Se encontraron %d errores durante la ejecución.', 
                         [Engine.GetErrorCount]));
          WriteLn(Format('Consulte el archivo de log para más detalles: %s', [LogFile]));
          if not Options.ContinueOnError then
            ExitCode := 1;
        end
        else
        begin
          WriteLn('');
          WriteLn('Script ejecutado exitosamente sin errores.');
        end;
        
      finally
        Engine.Free;
        Provider.Disconnect;
      end;
    finally
      Provider := nil;
    end;
    
  except
    on E: Exception do
    begin
      WriteLn('');
      WriteLn('ERROR FATAL: ' + E.Message);
      ExitCode := 1;
    end;
  end;
end.
