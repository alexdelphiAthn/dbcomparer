@echo off
REM ============================================
REM Script de Copia y Restauración Automática
REM ============================================
REM
REM Este script copia una BD de producción a desarrollo
REM Usa DBBackup para exportar y DBRestore para importar
REM

SETLOCAL EnableDelayedExpansion

REM ========== CONFIGURACIÓN ==========

REM Base de datos origen (producción)
SET SRC_HOST=servidor-produccion.empresa.com
SET SRC_PORT=3306
SET SRC_USER=backup_user
SET SRC_PASS=clave_backup
SET SRC_DB=produccion

REM Base de datos destino (desarrollo)
SET DST_HOST=localhost
SET DST_PORT=3306
SET DST_USER=root
SET DST_PASS=desarrollo
SET DST_DB=desarrollo

REM Herramientas
SET DBBACKUP=C:\Herramientas\DBBackup.exe
SET DBRESTORE=C:\Herramientas\DBRestore.exe

REM Directorio temporal
SET TEMP_DIR=C:\Temp\DB_Transfer
SET BACKUP_FILE=%TEMP_DIR%\backup_temp.sql

REM Opciones
SET BACKUP_OPTIONS=--exclude logs --exclude auditoria
SET RESTORE_OPTIONS=--continue-on-error

REM ===================================

echo.
echo ============================================
echo Copia de BD: Produccion a Desarrollo
echo ============================================
echo Origen: %SRC_HOST%:%SRC_DB%
echo Destino: %DST_HOST%:%DST_DB%
echo ============================================
echo.

REM Crear directorio temporal
IF NOT EXIST "%TEMP_DIR%" mkdir "%TEMP_DIR%"

REM ===================================
REM PASO 1: HACER BACKUP
REM ===================================

echo [PASO 1] Creando backup de %SRC_DB%...
echo.

"%DBBACKUP%" -h %SRC_HOST% -P %SRC_PORT% -u %SRC_USER% -p %SRC_PASS% -d %SRC_DB% -o "%BACKUP_FILE%" %BACKUP_OPTIONS%

IF ERRORLEVEL 1 (
    echo.
    echo ERROR: Fallo al crear el backup
    PAUSE
    EXIT /B 1
)

echo.
echo [OK] Backup creado exitosamente
echo.

REM ===================================
REM PASO 2: RESTAURAR EN DESTINO
REM ===================================

echo [PASO 2] Restaurando en %DST_DB%...
echo.

REM Preguntar confirmación
SET /P CONFIRMAR=¿Desea continuar con la restauración? Esto SOBRESCRIBIRÁ %DST_DB% (S/N): 

IF /I NOT "%CONFIRMAR%"=="S" (
    echo Operación cancelada por el usuario.
    PAUSE
    EXIT /B 0
)

echo.
echo Ejecutando restauración...
echo.

"%DBRESTORE%" -h %DST_HOST% -P %DST_PORT% -u %DST_USER% -p %DST_PASS% -d %DST_DB% -i "%BACKUP_FILE%" %RESTORE_OPTIONS%

IF ERRORLEVEL 1 (
    echo.
    echo ADVERTENCIA: La restauración completó con errores
    echo Revise el archivo de log para más detalles
) ELSE (
    echo.
    echo [OK] Restauración completada exitosamente
)

REM ===================================
REM PASO 3: LIMPIEZA
REM ===================================

echo.
SET /P BORRAR=¿Desea borrar el archivo temporal de backup? (S/N): 

IF /I "%BORRAR%"=="S" (
    del "%BACKUP_FILE%"
    echo Archivo temporal eliminado.
)

echo.
echo ============================================
echo Proceso completado
echo ============================================
echo.

PAUSE
