program DBBackup;

{$APPTYPE CONSOLE}

{$R *.res}

uses
  System.SysUtils,
  System.Classes,
  Backup.Engine in 'Backup.Engine.pas',
  Backup.Types in 'Backup.Types.pas',
  Providers.MySQL in 'Providers_MySQL.pas',
  Providers.MySQL.Helpers in 'Providers_MySQL_Helpers.pas',
  Core.Interfaces in 'Core_Interfaces.pas',
  Core.Types in 'Core_Types.pas',
  Core.Helpers in 'Core_Helpers.pas',
  ScriptWriters in 'ScriptWriters.pas';

var
  Host, Database, User, Password, OutputFile: string;
  Port: Integer;
  IncludeTables, ExcludeTables: TStringList;
  Provider: IDBMetadataProvider;
  Helpers: IDBHelpers;
  Writer: IScriptWriter;
  Engine: TDBBackupEngine;
  Options: TBackupOptions;
  i: Integer;
  Param: string;

begin
  try
    // Valores por defecto
    Host := 'localhost';
    Port := 3306;
    Database := '';
    User := 'root';
    Password := '';
    OutputFile := '';
    
    IncludeTables := TStringList.Create;
    ExcludeTables := TStringList.Create;
    try
      IncludeTables.CaseSensitive := False;
      ExcludeTables.CaseSensitive := False;
      
      // Opciones por defecto
      Options.WithData := True;
      Options.WithTriggers := True;
      Options.WithProcedures := True;
      Options.WithFunctions := True;
      Options.WithViews := True;
      Options.DropTablesFirst := False;
      Options.UseTransactions := True;
      
      // Parsear parámetros
      i := 1;
      while i <= ParamCount do
      begin
        Param := ParamStr(i);
        
        if (Param = '-h') or (Param = '--host') then
        begin
          Inc(i);
          if i <= ParamCount then Host := ParamStr(i);
        end
        else if (Param = '-P') or (Param = '--port') then
        begin
          Inc(i);
          if i <= ParamCount then Port := StrToIntDef(ParamStr(i), 3306);
        end
        else if (Param = '-u') or (Param = '--user') then
        begin
          Inc(i);
          if i <= ParamCount then User := ParamStr(i);
        end
        else if (Param = '-p') or (Param = '--password') then
        begin
          Inc(i);
          if i <= ParamCount then Password := ParamStr(i);
        end
        else if (Param = '-d') or (Param = '--database') then
        begin
          Inc(i);
          if i <= ParamCount then Database := ParamStr(i);
        end
        else if (Param = '-o') or (Param = '--output') then
        begin
          Inc(i);
          if i <= ParamCount then OutputFile := ParamStr(i);
        end
        else if (Param = '--include') then
        begin
          Inc(i);
          if i <= ParamCount then IncludeTables.Add(ParamStr(i));
        end
        else if (Param = '--exclude') then
        begin
          Inc(i);
          if i <= ParamCount then ExcludeTables.Add(ParamStr(i));
        end
        else if (Param = '--structure-only') then
          Options.WithData := False
        else if (Param = '--no-triggers') then
          Options.WithTriggers := False
        else if (Param = '--no-procedures') then
          Options.WithProcedures := False
        else if (Param = '--no-functions') then
          Options.WithFunctions := False
        else if (Param = '--no-views') then
          Options.WithViews := False
        else if (Param = '--drop-tables') then
          Options.DropTablesFirst := True
        else if (Param = '--no-transactions') then
          Options.UseTransactions := False
        else if (Param = '--help') then
        begin
          WriteLn('DBBackup - Utilidad de backup para MySQL');
          WriteLn('');
          WriteLn('Uso: DBBackup [opciones]');
          WriteLn('');
          WriteLn('Opciones de conexión:');
          WriteLn('  -h, --host <host>         Host del servidor MySQL (default: localhost)');
          WriteLn('  -P, --port <port>         Puerto del servidor MySQL (default: 3306)');
          WriteLn('  -u, --user <user>         Usuario de MySQL (default: root)');
          WriteLn('  -p, --password <pass>     Contraseña de MySQL');
          WriteLn('  -d, --database <db>       Nombre de la base de datos (REQUERIDO)');
          WriteLn('');
          WriteLn('Opciones de salida:');
          WriteLn('  -o, --output <file>       Archivo de salida (default: <database>_backup_YYYYMMDD_HHMMSS.sql)');
          WriteLn('');
          WriteLn('Opciones de filtrado:');
          WriteLn('  --include <table>         Incluir solo esta tabla (repetible)');
          WriteLn('  --exclude <table>         Excluir esta tabla (repetible)');
          WriteLn('');
          WriteLn('Opciones de contenido:');
          WriteLn('  --structure-only          Solo estructura, sin datos');
          WriteLn('  --no-triggers             No incluir triggers');
          WriteLn('  --no-procedures           No incluir procedimientos almacenados');
          WriteLn('  --no-functions            No incluir funciones');
          WriteLn('  --no-views                No incluir vistas');
          WriteLn('  --drop-tables             Incluir DROP TABLE antes de CREATE TABLE');
          WriteLn('  --no-transactions         No usar transacciones');
          WriteLn('');
          WriteLn('Ejemplos:');
          WriteLn('  DBBackup -d mydb -o backup.sql');
          WriteLn('  DBBackup -h 192.168.1.100 -u admin -p secret -d mydb');
          WriteLn('  DBBackup -d mydb --include customers --include orders');
          WriteLn('  DBBackup -d mydb --exclude logs --structure-only');
          Exit;
        end;
        Inc(i);
      end;
      
      // Validar parámetros requeridos
      if Database = '' then
      begin
        WriteLn('Error: Debe especificar una base de datos con -d o --database');
        WriteLn('Use --help para ver las opciones disponibles');
        Exit;
      end;
      
      // Generar nombre de archivo si no se especificó
      if OutputFile = '' then
        OutputFile := Format('%s_backup_%s.sql', 
                            [Database, FormatDateTime('yyyymmdd_hhnnss', Now)]);
      
      WriteLn('==============================================');
      WriteLn('DBBackup - Generando backup de MySQL');
      WriteLn('==============================================');
      WriteLn(Format('Host: %s:%d', [Host, Port]));
      WriteLn(Format('Base de datos: %s', [Database]));
      WriteLn(Format('Usuario: %s', [User]));
      WriteLn(Format('Archivo de salida: %s', [OutputFile]));
      WriteLn('==============================================');
      WriteLn('');
      
      // Crear instancias
      Provider := TMySQLMetadataProvider.Create(Host, Port, Database, User, Password);
      Helpers := TMySQLHelpers.Create;
      Writer := TScriptWriter.Create(OutputFile);
      
      try
        Engine := TDBBackupEngine.Create(Provider, Writer, Helpers, 
                                         Options, IncludeTables, ExcludeTables);
        try
          WriteLn('Conectando a la base de datos...');
          Provider.Connect;
          WriteLn('Conexión establecida.');
          WriteLn('');
          
          WriteLn('Generando backup...');
          Engine.GenerateBackup;
          WriteLn('');
          
          WriteLn('==============================================');
          WriteLn('Backup completado exitosamente');
          WriteLn(Format('Archivo generado: %s', [OutputFile]));
          WriteLn('==============================================');
        finally
          Engine.Free;
          Provider.Disconnect;
        end;
      finally
        Writer := nil;
        Helpers := nil;
        Provider := nil;
      end;
      
    finally
      IncludeTables.Free;
      ExcludeTables.Free;
    end;
    
  except
    on E: Exception do
    begin
      WriteLn('');
      WriteLn('ERROR: ' + E.Message);
      ExitCode := 1;
    end;
  end;
end.
