unit Backup.Types;

interface

type
  TBackupOptions = record
    WithData: Boolean;              // Incluir datos o solo estructura
    WithTriggers: Boolean;          // Incluir triggers
    WithProcedures: Boolean;        // Incluir procedimientos
    WithFunctions: Boolean;         // Incluir funciones
    WithViews: Boolean;             // Incluir vistas
    DropTablesFirst: Boolean;       // Incluir DROP TABLE antes de CREATE
    UseTransactions: Boolean;       // Envolver en BEGIN/COMMIT
  end;

implementation

end.
