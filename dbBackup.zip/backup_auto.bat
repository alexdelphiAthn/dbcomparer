@echo off
REM ============================================
REM Script de Backup Automático
REM ============================================
REM
REM Este script crea backups diarios de tus bases de datos MySQL
REM Puedes programarlo con el Programador de Tareas de Windows
REM
REM Uso:
REM   backup_auto.bat
REM
REM Configuración en las variables de abajo:

SETLOCAL EnableDelayedExpansion

REM ========== CONFIGURACIÓN ==========

REM Datos de conexión
SET DB_HOST=localhost
SET DB_PORT=3306
SET DB_USER=root
SET DB_PASS=tu_password

REM Bases de datos a respaldar (separadas por espacios)
SET DATABASES=mibd1 mibd2 mibd3

REM Directorio donde guardar los backups
SET BACKUP_DIR=C:\Backups\MySQL

REM Ruta al ejecutable DBBackup.exe
SET DBBACKUP=C:\Herramientas\DBBackup.exe

REM Opciones adicionales (opcional)
REM Ejemplos:
REM   --exclude logs
REM   --no-triggers
REM   --structure-only
SET EXTRA_OPTIONS=

REM Días a mantener backups antiguos (0 = nunca borrar)
SET RETENTION_DAYS=7

REM ===================================

REM Crear directorio si no existe
IF NOT EXIST "%BACKUP_DIR%" (
    mkdir "%BACKUP_DIR%"
    echo Directorio de backup creado: %BACKUP_DIR%
)

REM Fecha para el nombre del archivo
FOR /F "tokens=1-3 delims=/ " %%a in ('date /t') do (
    SET FECHA=%%c%%b%%a
)

FOR /F "tokens=1-2 delims=: " %%a in ('time /t') do (
    SET HORA=%%a%%b
)

SET TIMESTAMP=%FECHA%_%HORA%

echo.
echo ============================================
echo Backup Automático de MySQL
echo ============================================
echo Fecha: %DATE% %TIME%
echo Host: %DB_HOST%:%DB_PORT%
echo Usuario: %DB_USER%
echo Directorio: %BACKUP_DIR%
echo ============================================
echo.

REM Contador de éxitos y errores
SET SUCCESS=0
SET ERRORS=0

REM Hacer backup de cada base de datos
FOR %%D IN (%DATABASES%) DO (
    echo [%TIME%] Respaldando %%D...
    
    SET OUTPUT_FILE=%BACKUP_DIR%\%%D_%TIMESTAMP%.sql
    
    "%DBBACKUP%" -h %DB_HOST% -P %DB_PORT% -u %DB_USER% -p %DB_PASS% -d %%D -o "!OUTPUT_FILE!" %EXTRA_OPTIONS%
    
    IF ERRORLEVEL 1 (
        echo [ERROR] Fallo al respaldar %%D
        SET /A ERRORS+=1
    ) ELSE (
        echo [OK] Backup completado: !OUTPUT_FILE!
        SET /A SUCCESS+=1
    )
    echo.
)

echo ============================================
echo Resumen
echo ============================================
echo Backups exitosos: %SUCCESS%
echo Backups fallidos: %ERRORS%
echo ============================================
echo.

REM Limpiar backups antiguos si RETENTION_DAYS > 0
IF %RETENTION_DAYS% GTR 0 (
    echo Limpiando backups anteriores a %RETENTION_DAYS% días...
    FORFILES /P "%BACKUP_DIR%" /M *.sql /D -%RETENTION_DAYS% /C "cmd /c echo Borrando @file && del @path" 2>NUL
    IF ERRORLEVEL 1 (
        echo No hay backups antiguos para borrar.
    )
    echo.
)

REM Log del resultado
echo [%DATE% %TIME%] Backup completado: %SUCCESS% OK, %ERRORS% errores >> "%BACKUP_DIR%\backup.log"

echo Proceso finalizado.
echo.

PAUSE
