# DBBackup - Utilidad de Backup para MySQL

## Descripción

DBBackup es una herramienta de línea de comandos para crear copias de seguridad completas de bases de datos MySQL. A diferencia del DBComparer que compara dos bases de datos, esta herramienta simplemente vuelca toda la estructura y datos de una base de datos a un archivo SQL.

## Características

- ✅ Backup completo de estructura de tablas
- ✅ Backup de datos con INSERT statements
- ✅ Backup de vistas, procedimientos, funciones y triggers
- ✅ Filtrado de tablas (incluir/excluir específicas)
- ✅ Opción de estructura solamente (sin datos)
- ✅ Incluye DROP TABLE antes de CREATE (opcional)
- ✅ Usa transacciones para importación más segura
- ✅ Genera nombres de archivo automáticos con timestamp

## Compilación

```
dcc32 DBBackup.dpr
```

O compila desde el IDE de Delphi.

## Requisitos

- Delphi 10.3 o superior
- UniDAC (Universal Data Access Components)
- Conexión a servidor MySQL/MariaDB

## Uso Básico

### Backup completo

```bash
DBBackup -d nombre_bd -o backup.sql
```

### Backup con autenticación

```bash
DBBackup -h 192.168.1.100 -u admin -p secreto -d nombre_bd
```

### Solo estructura (sin datos)

```bash
DBBackup -d nombre_bd --structure-only
```

### Filtrar tablas específicas

```bash
# Solo incluir ciertas tablas
DBBackup -d nombre_bd --include clientes --include pedidos

# Excluir tablas específicas
DBBackup -d nombre_bd --exclude logs --exclude temp
```

### Con DROP TABLE

```bash
DBBackup -d nombre_bd --drop-tables
```

## Opciones de Conexión

| Opción | Descripción | Default |
|--------|-------------|---------|
| `-h, --host` | Host del servidor MySQL | localhost |
| `-P, --port` | Puerto del servidor | 3306 |
| `-u, --user` | Usuario de MySQL | root |
| `-p, --password` | Contraseña | (vacío) |
| `-d, --database` | Nombre de la BD | **REQUERIDO** |

## Opciones de Salida

| Opción | Descripción | Default |
|--------|-------------|---------|
| `-o, --output` | Archivo de salida | `<database>_backup_YYYYMMDD_HHMMSS.sql` |

## Opciones de Filtrado

| Opción | Descripción |
|--------|-------------|
| `--include <tabla>` | Incluir solo esta tabla (repetible) |
| `--exclude <tabla>` | Excluir esta tabla (repetible) |

## Opciones de Contenido

| Opción | Descripción | Default |
|--------|-------------|---------|
| `--structure-only` | Solo estructura, sin datos | false |
| `--no-triggers` | No incluir triggers | false |
| `--no-procedures` | No incluir procedimientos | false |
| `--no-functions` | No incluir funciones | false |
| `--no-views` | No incluir vistas | false |
| `--drop-tables` | Incluir DROP TABLE | false |
| `--no-transactions` | No usar transacciones | false |

## Ejemplos de Uso

### 1. Backup completo automático

```bash
DBBackup -d mibasedatos
```

Genera: `mibasedatos_backup_20250214_153045.sql`

### 2. Backup a servidor remoto

```bash
DBBackup -h db.empresa.com -P 3307 -u backup_user -p Mi_Clave_123 -d produccion -o produccion_backup.sql
```

### 3. Solo tablas de clientes y ventas

```bash
DBBackup -d erp --include clientes --include ventas --include productos
```

### 4. Todo excepto tablas de logs

```bash
DBBackup -d miapp --exclude logs --exclude auditoria --exclude sessions
```

### 5. Solo estructura para desarrollo

```bash
DBBackup -d produccion --structure-only -o estructura_dev.sql
```

### 6. Backup completo con DROP TABLE para reemplazar BD

```bash
DBBackup -d origen --drop-tables -o restaurar_completo.sql
```

### 7. Backup sin triggers ni procedures

```bash
DBBackup -d mibd --no-triggers --no-procedures --no-functions
```

## Formato del Archivo de Salida

El archivo SQL generado incluye:

1. **Cabecera** con información del backup
2. **Configuración MySQL** (desactivar checks para importar más rápido)
3. **Inicio de transacción** (si está habilitado)
4. **Tablas**: CREATE TABLE + datos (INSERT)
5. **Vistas**: CREATE VIEW
6. **Procedimientos**: CREATE PROCEDURE
7. **Funciones**: CREATE FUNCTION
8. **Triggers**: CREATE TRIGGER
9. **Restauración de configuración**
10. **Commit de transacción**

## Restaurar un Backup

Para restaurar el backup generado:

```bash
mysql -u root -p nombre_bd < backup.sql
```

O desde MySQL:

```sql
USE nombre_bd;
SOURCE /ruta/al/backup.sql;
```

## Diferencias con DBComparer

| Característica | DBBackup | DBComparer |
|----------------|----------|------------|
| Propósito | Crear backup completo | Comparar dos BDs |
| Destino | Archivo SQL | Archivo SQL |
| Conexiones | Una (origen) | Dos (origen + destino) |
| Salida | CREATE + INSERT | ALTER + UPDATE + INSERT |
| Uso típico | Copias de seguridad | Sincronización/migración |

## Notas Importantes

- El archivo generado puede ser muy grande si la BD tiene muchos datos
- Los INSERT se generan uno por uno (no usa INSERT masivo)
- Se respetan las claves foráneas desactivando temporalmente los checks
- Los triggers se crean al final porque dependen de las tablas
- Compatible con MySQL 5.7+ y MariaDB 10.3+

## Estructura del Proyecto

```
DBBackup.dpr                  - Programa principal
Backup.Engine.pas             - Motor de backup
Backup.Types.pas              - Tipos y opciones
Core_Engine.pas               - Motor del comparador (actualizado)
Core_Interfaces.pas           - Interfaces actualizadas
Core_Helpers.pas              - Helpers base
Core_Types.pas                - Tipos comunes
Providers_MySQL.pas           - Provider MySQL actualizado
Providers_MySQL_Helpers.pas   - Helpers MySQL actualizados
ScriptWriters.pas             - Escritor de scripts
```

## Solución de Problemas

### Error: "Must specify database"

Asegúrate de usar `-d nombre_bd` o `--database nombre_bd`.

### Error de conexión

Verifica:
- Host y puerto correctos
- Usuario tiene permisos SELECT en la BD
- Firewall permite conexión al puerto MySQL

### Archivo muy grande

Usa `--structure-only` o filtra con `--include`/`--exclude`.

### Triggers no se crean

Asegúrate que el usuario tiene privilegio TRIGGER:

```sql
GRANT TRIGGER ON nombre_bd.* TO 'usuario'@'host';
```

## Autor

Alejandro La Orden
2025

## Licencia

Uso libre para proyectos personales y comerciales.
