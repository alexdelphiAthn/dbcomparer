#!/bin/bash
############################################
# Script de Backup Automático MySQL
############################################
#
# Este script crea backups diarios de bases de datos MySQL
# Puedes programarlo con cron
#
# Agregar a crontab:
#   0 2 * * * /ruta/a/backup_auto.sh
#   (Ejecuta todos los días a las 2:00 AM)
#

# ========== CONFIGURACIÓN ==========

# Datos de conexión
DB_HOST="localhost"
DB_PORT="3306"
DB_USER="root"
DB_PASS="tu_password"

# Bases de datos a respaldar (separadas por espacios)
DATABASES="mibd1 mibd2 mibd3"

# Directorio donde guardar los backups
BACKUP_DIR="/var/backups/mysql"

# Ruta al ejecutable DBBackup (o usar wine si es Windows)
# DBBACKUP="wine /opt/DBBackup/DBBackup.exe"
# O si tienes versión compilada para Linux:
DBBACKUP="/usr/local/bin/dbbackup"

# Opciones adicionales (opcional)
EXTRA_OPTIONS=""

# Días a mantener backups antiguos
RETENTION_DAYS=7

# ===================================

# Crear directorio si no existe
mkdir -p "$BACKUP_DIR"

# Timestamp
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

echo ""
echo "============================================"
echo "Backup Automático de MySQL"
echo "============================================"
echo "Fecha: $(date)"
echo "Host: $DB_HOST:$DB_PORT"
echo "Usuario: $DB_USER"
echo "Directorio: $BACKUP_DIR"
echo "============================================"
echo ""

# Contadores
SUCCESS=0
ERRORS=0

# Hacer backup de cada base de datos
for DB in $DATABASES; do
    echo "[$(date +%H:%M:%S)] Respaldando $DB..."
    
    OUTPUT_FILE="$BACKUP_DIR/${DB}_${TIMESTAMP}.sql"
    
    $DBBACKUP -h $DB_HOST -P $DB_PORT -u $DB_USER -p $DB_PASS -d $DB -o "$OUTPUT_FILE" $EXTRA_OPTIONS
    
    if [ $? -eq 0 ]; then
        echo "[OK] Backup completado: $OUTPUT_FILE"
        # Comprimir el backup
        gzip "$OUTPUT_FILE"
        echo "[OK] Comprimido: ${OUTPUT_FILE}.gz"
        ((SUCCESS++))
    else
        echo "[ERROR] Fallo al respaldar $DB"
        ((ERRORS++))
    fi
    echo ""
done

echo "============================================"
echo "Resumen"
echo "============================================"
echo "Backups exitosos: $SUCCESS"
echo "Backups fallidos: $ERRORS"
echo "============================================"
echo ""

# Limpiar backups antiguos
if [ $RETENTION_DAYS -gt 0 ]; then
    echo "Limpiando backups anteriores a $RETENTION_DAYS días..."
    find "$BACKUP_DIR" -name "*.sql.gz" -type f -mtime +$RETENTION_DAYS -delete
    find "$BACKUP_DIR" -name "*.sql" -type f -mtime +$RETENTION_DAYS -delete
    echo ""
fi

# Log del resultado
echo "[$(date)] Backup completado: $SUCCESS OK, $ERRORS errores" >> "$BACKUP_DIR/backup.log"

echo "Proceso finalizado."
echo ""
